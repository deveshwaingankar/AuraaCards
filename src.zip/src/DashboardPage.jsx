// src/pages/DashboardPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  HomeIcon,
  CreditCardIcon,
  ClockIcon,
  UserIcon,
  LifeBuoyIcon,
  LogOutIcon,
  PlusIcon,
  RefreshCwIcon,
  DownloadIcon,
  Menu as MenuIcon,
  X as XIcon,
} from "lucide-react";
import Navbar from "./Navbar";

export default function DashboardPage() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Mock user data
  const initialUser = {
    name: "Jane Doe",
    photoUrl: "",
    cards: [{ id: "c1", name: "Hello Card", image: "/images/purple-card.png" }],
    transactions: [
      { id: "t1", date: "2025-07-20", card: "Hello Card", amount: 6, status: "Complete" },
      { id: "t2", date: "2025-07-18", card: "Hello Card", amount: 6, status: "Complete" },
      { id: "t3", date: "2025-07-15", card: "Hello Card", amount: 6, status: "Pending" },
    ],
    activity: [
      { month: "Jan", count: 2 }, { month: "Feb", count: 5 },
      { month: "Mar", count: 3 }, { month: "Apr", count: 4 },
      { month: "May", count: 6 }, { month: "Jun", count: 1 },
      { month: "Jul", count: 3 },
    ],
    profile: { email: "jane@example.com", phone: "555-1234" },
  };
  const [user, setUser] = useState(initialUser);

  // Upload & preview profile photo
  const handlePhotoChange = e => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setUser(u => ({ ...u, photoUrl: reader.result }));
    reader.readAsDataURL(file);
  };

  const toggleSidebar = () => setSidebarOpen(o => !o);

  // Sidebar component
  const Sidebar = () => (
    <aside
      className={`
        fixed top-16 bottom-0 left-0 w-64 bg-zinc-900 p-6
        transform transition-transform
        z-30
        md:relative md:top-0 md:bottom-auto md:translate-x-0
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
      `}
    >
      {/* Only show this close-X inside sidebar on mobile */}
      <button
        onClick={toggleSidebar}
        className="absolute top-4 right-4 md:hidden p-1 bg-zinc-800 rounded"
      >
        <XIcon size={20} />
      </button>

      <div className="mb-8">
        <p className="text-gray-400 text-sm">Signed in as</p>
        <p className="text-lg font-semibold">{user.name}</p>
      </div>
      <nav className="space-y-4">
        {[
          { label: "Dashboard", icon: <HomeIcon />, to: "/dashboard" },
          { label: "Cards",     icon: <CreditCardIcon />, to: "/cards" },
          { label: "Activity",  icon: <ClockIcon />,      to: "/activity" },
          { label: "Profile",   icon: <UserIcon />,       to: "/profile" },
          { label: "Support",   icon: <LifeBuoyIcon />,   to: "/support" },
        ].map(item => (
          <button
            key={item.label}
            onClick={() => { navigate(item.to); setSidebarOpen(false); }}
            className="flex items-center gap-3 text-gray-200 hover:text-white w-full"
          >
            {item.icon}<span>{item.label}</span>
          </button>
        ))}
      </nav>
      <button
        onClick={() => { navigate("/logout"); setSidebarOpen(false); }}
        className="mt-8 flex items-center gap-3 text-red-400 hover:text-red-500"
      >
        <LogOutIcon /><span>Sign out</span>
      </button>
    </aside>
  );

  // Quick Actions
  const QuickActions = () => (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 space-y-4">
      <h3 className="font-semibold">Quick Actions</h3>
      <button
        onClick={() => navigate("/signup")}
        className="w-full flex items-center gap-3 px-4 py-2 bg-zinc-800 rounded hover:bg-zinc-700"
      >
        <PlusIcon /><span>Link New Card</span>
      </button>
      <button
        onClick={() => window.location.reload()}
        className="w-full flex items-center gap-3 px-4 py-2 bg-zinc-800 rounded hover:bg-zinc-700"
      >
        <RefreshCwIcon /><span>Refresh Cards</span>
      </button>
      <button
        onClick={() => alert("Downloading...")}
        className="w-full flex items-center gap-3 px-4 py-2 bg-zinc-800 rounded hover:bg-zinc-700"
      >
        <DownloadIcon /><span>Download Cards</span>
      </button>
    </div>
  );

  // Stats Chart
  const StatsChart = ({ data }) => (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-4">
      <h3 className="font-semibold mb-2">Monthly Activity</h3>
      <ResponsiveContainer width="100%" height={120}>
        <LineChart data={data}>
          <XAxis dataKey="month" stroke="#888" />
          <YAxis stroke="#888" />
          <Tooltip contentStyle={{ backgroundColor: "#333", border: "none" }} />
          <Line type="monotone" dataKey="count" stroke="#F97316" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );

  // Profile Summary
  const ProfileSummary = ({ profile }) => (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 space-y-3">
      <h3 className="font-semibold">Profile</h3>
      <div><strong>Email:</strong> {profile.email}</div>
      <div><strong>Phone:</strong> {profile.phone}</div>
    </div>
  );

  // Transactions Table
  const TransactionsTable = ({ data }) => (
    <div className="overflow-x-auto bg-white/5 backdrop-blur-md rounded-xl">
      <table className="min-w-full table-auto">
        <thead className="bg-white/10">
          <tr>
            <th className="px-4 py-2 text-left">Date</th>
            <th className="px-4 py-2 text-left">Card</th>
            <th className="px-4 py-2 text-left">Amount</th>
            <th className="px-4 py-2 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {data.map(tx => (
            <tr key={tx.id} className="hover:bg-white/10">
              <td className="px-4 py-2">{tx.date}</td>
              <td className="px-4 py-2">{tx.card}</td>
              <td className="px-4 py-2">${tx.amount.toFixed(2)}</td>
              <td className="px-4 py-2">{tx.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-black text-white">
      <Navbar />

      {/* Hamburger only when closed */}
      {!sidebarOpen && (
        <button
          className="fixed top-12 left-4 z-50 p-2 bg-zinc-800 rounded-md md:hidden"
          onClick={toggleSidebar}
        >
          <MenuIcon size={24} />
        </button>
      )}

      {/* Overlay (closes on click) */}
      {sidebarOpen && (
        <div
          onClick={toggleSidebar}
          className="fixed top-16 bottom-0 left-0 right-0 bg-black/50 z-20 md:hidden"
        />
      )}

      <Sidebar />

      <main className="flex-1 pt-16 md:pt-20 p-4 md:p-6 lg:p-8 overflow-auto">
        <h1 className="text-3xl font-bold mb-6">
          Welcome back, {user.name.split(" ")[0]}
        </h1>

        {/* Profile photo & card */}
        <div className="flex flex-col items-center mb-8 space-y-4">
          {user.photoUrl ? (
            <img
              src={user.photoUrl}
              alt="Profile"
              className="w-24 h-24 rounded-full object-cover border-2 border-orange-500"
            />
          ) : (
            <div className="w-24 h-24 rounded-full bg-zinc-800 flex items-center justify-center border-2 border-zinc-600">
              <UserIcon className="text-zinc-500" size={32} />
            </div>
          )}
          <label className="text-sm bg-zinc-700 px-3 py-1 rounded hover:bg-zinc-600 cursor-pointer">
            {user.photoUrl ? "Change Photo" : "Upload Photo"}
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoChange}
              className="hidden"
            />
          </label>

          <div className="w-64 h-40 bg-transparent rounded-xl flex items-center justify-center">
            <img
              src={user.cards[0].image}
              alt={user.cards[0].name}
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Widgets */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <QuickActions />
          <StatsChart data={user.activity} />
          <ProfileSummary profile={user.profile} />
        </div>

        {/* Recent Transactions */}
        <section className="mb-12">
          <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
          <TransactionsTable data={user.transactions} />
        </section>
      </main>
    </div>
  );
}
