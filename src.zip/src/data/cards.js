export const cards = [
  {
    id: 'card1',
    name: 'Hi Card',
    image: '/images/yellow-card.png',
    price: 5,
    description: 'Make a bold introduction at any event.'
  },
  {
    id: 'card2',
    name: 'Hello Card',
    image: '/images/purple-card.png',
    price: 6,
    description: 'Say hello in style with seamless NFC sharing.'
  },
  {
    id: 'card3',
    name: 'Honored Card',
    image: '/images/green-card.png',
    price: 7,
    description: 'Show gratitude with a premium greeting.'
  }
];