import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CardShowcase from './HomePage';
import CartPage from './CartPage';
import Layout from "./Layout";
import CheckoutPage from "./CheckoutPage";
import SignupPage     from "./SignupPage";
import SetupCardPage  from "./SetupCardPage";
import DashboardPage  from "./DashboardPage";
import ProfileCard from './ProfileCard';


export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<CardShowcase />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/setup-card/:userId" element={<SetupCardPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />    
          <Route path="/profile" element={<ProfileCard />} />      
        </Routes>
      </Layout>
    </Router>
  );
}
