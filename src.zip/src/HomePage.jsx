// src/pages/HomePage.jsx
import { useState } from "react";
import { motion } from "framer-motion";
import Navbar from "./Navbar";
import { cards } from "./data/cards";

export default function HomePage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);

  // constants for carousel
  const CARD_WIDTH = 300 + 16;       // px: card width + gap
  const groupWidth = CARD_WIDTH * cards.length;
  // duplicate cards array so loop is seamless
  const loopCards = [...cards, ...cards];

  return (
    <div className="relative min-h-screen bg-black text-white font-sans overflow-hidden">
      {/* NAVBAR */}
      <Navbar />

      {/* IMAGE CAROUSEL */}
      <div className="mt-24 mb-12 flex justify-center">
        <div className="w-full overflow-hidden max-w-4xl">
          <motion.div
            className="flex gap-4"
            style={{ width: groupWidth * 2 }}
            animate={{ x: [0, -groupWidth] }}
            transition={{
              x: {
                repeat: Infinity,
                repeatType: "loop",
                duration: 12,
                ease: "linear",
              },
            }}
          >
            {loopCards.map((c, idx) => (
              <div
                key={`${c.id}-${idx}`}
                className="flex-shrink-0 w-[300px] h-[180px] bg-transparent rounded-xl flex items-center justify-center"
              >
                <img
                  src={c.image}
                  alt={c.name}
                  className="w-full h-full object-contain"
                />
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* HERO TEXT */}
      <section className="px-6 text-center">
        <h1 className="text-4xl md:text-5xl font-bold">
          Simple and <span className="text-gray-400">transparent</span> business transactions
        </h1>
        <p className="mt-4 max-w-xl mx-auto text-gray-300">
          Step into our innovation oasis, where groundbreaking ideas bloom, and every click is a step into a world of endless possibilities.
        </p>
      </section>

      {/* MEMBER LOGIN */}
      <section className="mt-10 mb-16 flex justify-center px-6">
        <form className="w-full max-w-sm bg-white/10 backdrop-blur-md rounded-xl p-6 space-y-4">
          <h2 className="text-xl font-semibold text-center">Member Login</h2>

          <div>
            <label className="block mb-1 text-sm">Username</label>
            <div className="flex items-center bg-transparent border border-zinc-600 rounded-full px-4 py-2">
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="Username"
                className="w-full bg-transparent focus:outline-none text-white"
              />
            </div>
          </div>

          <div>
            <label className="block mb-1 text-sm">Password</label>
            <div className="flex items-center bg-transparent border border-zinc-600 rounded-full px-4 py-2">
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full bg-transparent focus:outline-none text-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={remember}
                onChange={() => setRemember(r => !r)}
                className="accent-orange-500"
              />
              Remember me
            </label>
            <a href="#" className="text-gray-300 hover:underline">
              Forgot password?
            </a>
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-orange-500 text-black font-semibold rounded-full hover:bg-orange-600 transition"
          >
            Login
          </button>

          <p className="text-center text-sm">
            Not a member?{" "}
            <a href="#" className="underline hover:text-orange-400">
              Create account
            </a>
          </p>
        </form>
      </section>
    </div>
  );
}
